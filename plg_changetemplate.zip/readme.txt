Plugin change template version 1.0.0 is designed for those sites owners who would like to change the templates (layouts)
of some menuitems (webpages) based on the groups and/or users.
The administrator has the power to create and delete original state of layouts from the backsite.
Also users and/or groups of chosen by administrator in backsite, will observe the new layout on login to site from frontend.
The file that keeps the original state of the layouts, could be deleted from backsite only by administrators. 
The file could be downloaded from: https://extensions.kwproductions121.ir/myplugins/changetemplate.html
Documentation @ : https//github.com/KianWilliam/ChangeTemplate
In case of any problem contact us at:
webarchitect@kwproductions121.ir
Long live science
Down with artificial intelligence unless enslaved under human intelligence!!!
