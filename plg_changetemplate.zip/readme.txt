Plugin change template version 1.0.0 is designed for those site owners who would like to change the templates (layouts)
of some menuitems (webpages) based on the groups and/or users.
The administrator has the power to create and delete original state of layouts from the backsite.
Administrators also could allow such permission to the chosen users from backend after login event, then new layouts
shall be replaced with the older ones and the original state will be kept in a file.
The last chosen user who logs out shall be caused the return of the original state. 
The file that keeps the original state of the layouts, could be deleted from backsite only by administrators. 
The file could be downloaded from: https://extensions.kwproductions121.ir/myplugins/changetemplate.html
You can not use this plugin with plugin multilanglog of this developer, if you are going to employ changetemplate plugin
you got to disable the other one.
Documentation @ : https//github.com/KianWilliam/ChangeTemplate
In case of any problem contact us at:
webarchitect@kwproductions121.ir
Long live science
Down with artificial intelligence unless enslaved under human intelligence!!!
